const WebSocket = require('ws');
const fs = require('fs');
const PORT = 3000;
const wss = new WebSocket.Server({ port: PORT });
let users = {};
let onlineUsers = [];
const dataFile = 'data.json';
if(fs.existsSync(dataFile)){ users = JSON.parse(fs.readFileSync(dataFile,'utf8')); }
function saveUsers(){ fs.writeFileSync(dataFile, JSON.stringify(users,null,2)); }
wss.on('connection', ws => {
  ws.on('message', msg => {
    let data = JSON.parse(msg);
    switch(data.type){
      case 'register':
        if(users[data.user]) return ws.send(JSON.stringify({error:"Username exists"}));
        users[data.user]={balance:0,pin:data.pin,isAdmin:false,isMain:false,ws:ws};
        saveUsers(); ws.send(JSON.stringify({success:"Registered"})); break;
      case 'login':
        if(!users[data.user]) return ws.send(JSON.stringify({error:"Not found"}));
        if(users[data.user].pin!==data.pin) return ws.send(JSON.stringify({error:"Wrong PIN"}));
        users[data.user].ws = ws;
        if(!onlineUsers.includes(data.user)) onlineUsers.push(data.user);
        broadcastOnline();
        ws.send(JSON.stringify({success:"Logged in",balance:users[data.user].balance})); break;
      case 'send':
        const from = users[data.from], to = users[data.to];
        if(!from || !to) return ws.send(JSON.stringify({error:"User not found"}));
        if(from.balance < data.amount) return ws.send(JSON.stringify({error:"Insufficient balance"}));
        from.balance -= data.amount; to.balance += data.amount;
        if(from.ws) from.ws.send(JSON.stringify({type:'updateBalance',from:data.from,to:data.to,amount:data.amount}));
        if(to.ws) to.ws.send(JSON.stringify({type:'updateBalance',from:data.from,to:data.to,amount:data.amount}));
        saveUsers(); break;
      case 'mainAdjust':
        const target = users[data.user]; if(!target) return;
        target.balance += data.amount;
        if(target.ws) target.ws.send(JSON.stringify({type:'updateBalance',from:'MainAdmin',to:data.user,amount:data.amount}));
        saveUsers(); break;
    }
  });
  ws.on('close', () => { onlineUsers = onlineUsers.filter(u => users[u].ws!==ws); broadcastOnline(); });
});
function broadcastOnline(){ wss.clients.forEach(c=>{ if(c.readyState===WebSocket.OPEN){ c.send(JSON.stringify({type:'online',list:onlineUsers})); } }); }
console.log(`WebSocket Server running on ws://localhost:${PORT}`);
