<?php
$dataFile = 'data.json';
if(!file_exists($dataFile)) file_put_contents($dataFile,json_encode([]));
$data = json_decode(file_get_contents($dataFile),true);
$action = $_GET['action'] ?? '';
switch($action){
  case 'getAll': echo json_encode($data); break;
  case 'getUser': $u=$_GET['user']??''; echo json_encode($data[$u]??null); break;
  case 'setUser': $u=$_POST['user']??''; $data[$u]=$_POST['data']??[]; file_put_contents($dataFile,json_encode($data)); echo "OK"; break;
}
?>
