# IP-to-IP Real-time Virtual Wallet
## Setup
1. Install Node.js (v14+ recommended)
2. Clone this repo
3. Install dependencies:
   npm install
4. Start server:
   node server.js
5. Open main.html in browser
## Notes
- Main Admin: username mafia boss, password @@mafia@@1880@@, PIN 1880
- Node.js WebSocket server required for live transfers
- Optional PHP (wallet.php) for persistent storage
- GitHub Pages cannot host live server — use VPS / local machine
